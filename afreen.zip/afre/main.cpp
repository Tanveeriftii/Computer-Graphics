#include <windows.h>
#include <GL/glut.h>
void day() {
glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
glClear(GL_COLOR_BUFFER_BIT);
 /* BUILDING */
 /*MAIN STRUCTURE*/
 /*Border UPPER */
 /*Main Building */
glBegin(GL_POLYGON);
glColor3ub(180, 233, 181);
glVertex2f(0.0f,20.0f);
glVertex2f(-15.0f,20.0f);
glVertex2f(-15.0f,-5.0f);
glVertex2f(0.0f,-5.0f);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(180, 233, 181);
glVertex2f(-15.0f,20.0f);
glVertex2f(-20.0f,20.0f);
glVertex2f(-20.0f,-5.0f);
glVertex2f(-15.0f,-5.0f);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(116, 243, 119);
glVertex2f(-10.0f,20.0f);
glVertex2f(-15.0f,20.0f);
glVertex2f(-15.0f,-5.0f);
glVertex2f(-10.0f,-5.0f);
glEnd();

glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-10.0f,15.0f);
glVertex2f(-20.0f,15.0f);
glEnd();
glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-10.0f,11.0f);
glVertex2f(-20.0f,11.0f);
glEnd();
glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-10.0f,7.0f);
glVertex2f(-20.0f,7.0f);
glEnd();
glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-10.0f,3.0f);
glVertex2f(-20.0f,3.0f);
glEnd();
glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-10.0f,-1.0f);
glVertex2f(-20.0f,-1.0f);
glEnd();





         /* right side*/
         glBegin(GL_POLYGON);
glColor3ub(255,255,255);
glVertex2f(-1.0f,15.0f);
glVertex2f(-5.0f,15.0f);
glVertex2f(-5.0f,10.0f);
glVertex2f(-1.0f,10.0f);
glEnd();
         glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-1.0f,12.0f);
glVertex2f(-3.0f,12.0f);

glEnd();
glLineWidth(2);
         glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-1.0f,12.0f);
glVertex2f(-5.0f,12.0f);

glEnd();
glLineWidth(3);
         glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(-3.0f,12.0f);
glVertex2f(-3.0f,14.0f);

glEnd();






                               /*LIGHT*/


glBegin(GL_POLYGON);
glColor3ub(180, 233, 181);
glVertex2f(10.0f,-4.0f);
glVertex2f(10.0f,-5.0f);
glVertex2f(20.0f,-5.0f);
glVertex2f(20.0f,-4.0f);
glEnd();
glLineWidth(10);
glBegin(GL_LINES);
glColor3ub(180, 233, 181);
glVertex2f(16.0f,-4.0f);
glVertex2f(16.0f,9.0f);

glEnd();


                         /*FAN WINDMILL*/
    glBegin(GL_TRIANGLES); //yeallow
    glColor3ub(255, 255, 0);
    glVertex2f(17.f, 12.f);    // x, y
	glVertex2f(15.f,12.f);
	glVertex2f(16.f, 8.5f);
	glEnd();

	 glBegin(GL_TRIANGLES); //yeallow
    glColor3ub(255, 255, 0);
    glVertex2f(12.f, 10.f);    // x, y
	glVertex2f(12.f,7.f);
	glVertex2f(16.f, 8.5f);
	glEnd();

	 glBegin(GL_TRIANGLES); //yeallow
    glColor3ub(255, 255, 0);
    glVertex2f(15.f, 5.f);    // x, y
	glVertex2f(17.f,5.f);
	glVertex2f(16.f, 8.5f);
	glEnd();
	glBegin(GL_TRIANGLES); //yeallow
    glColor3ub(255, 255, 0);
    glVertex2f(20.f, 7.f);    // x, y
	glVertex2f(20.f,10.f);
	glVertex2f(16.f, 8.5f);
	glEnd();






;


                              /*TREE*/

glBegin(GL_POLYGON);
glColor3ub(126, 53, 23);
glVertex2f(4.0f,0.0f);
glVertex2f(5.0f,0.0f);
glVertex2f(5.0f,5.0f);
glVertex2f(4.0f,5.0f);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(126, 53, 23);
glVertex2f(3.0f,0.0f);
glVertex2f(4.0f,0.0f);
glVertex2f(4.0f,5.0f);
glVertex2f(3.0f,5.0f);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(126, 53, 23);
glVertex2f(4.0f,0.0f);
glVertex2f(4.0f,-5.0f);
glVertex2f(5.0f,-5.0f);
glVertex2f(5.0f,0.0f);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(126, 53, 23);
glVertex2f(3.0f,0.0f);
glVertex2f(4.0f,0.0f);
glVertex2f(4.0f,-5.0f);
glVertex2f(3.0f,-5.0f);
glEnd();
glBegin(GL_TRIANGLES);
glColor3ub(0, 128, 0);
glVertex2f(0.f,5.f);
glVertex2f(8.f,5.f);
glVertex2f(4.f,8.f);
glEnd();
glBegin(GL_TRIANGLES);
glColor3ub(0, 255, 0);
glVertex2f(0.f,6.f);
glVertex2f(8.f,6.f);
glVertex2f(4.f,11.f);
glEnd();




glFlush();
}
void sound()
{
    PlaySound("acoustic-guitar-dream-30-seconds-4642.wav",NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);
}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {

        case 'd':
            glutDisplayFunc(day);
	        glutKeyboardFunc(handleKeypress);
             sound();
	        glutPostRedisplay();
            break;



    }
}
int main(int argc, char** argv) {
glutInit(&argc, argv);
glutCreateWindow("OpenGL Setup Test");
glutInitWindowSize(320, 320);
gluOrtho2D(-30,30,-30,30);
glutDisplayFunc(day);
glutKeyboardFunc(handleKeypress);
glutMainLoop();
return 0;
}
